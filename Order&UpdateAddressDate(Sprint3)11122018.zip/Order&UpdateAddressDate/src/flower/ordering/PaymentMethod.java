package flower.ordering;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class PaymentMethod extends javax.swing.JFrame {

    private final String SQL_SELECT = "SELECT * FROM dateaddress inner join customer on customer.custic = dateaddress.customerid where dateaddress.ORDERID = ? ";
    private final String SQL_UPDATE = "UPDATE DATEADDRESS SET STATUS = ? "+ "WHERE ORDERID = ?";
    
    
    private Connection con;
    private PreparedStatement pStmt_Select, pStmt_Update;
    
    
    private void initDbConnection() throws SQLException {
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/FlowerShopDB", "nbuser", "nbuser");
    }

    private void initPrepareStatement() throws SQLException {

        pStmt_Select = con.prepareStatement(SQL_SELECT);
        pStmt_Update = con.prepareStatement(SQL_UPDATE);

    }
    
    
    
    
    public PaymentMethod() {
         try {
        initDbConnection();
        initPrepareStatement();
         }catch(SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
         }
        initComponents();
            Nametxt.setEditable(false);
            Addresstxt.setEditable(false);
            DateTimetxt.setEditable(false);
            Paymenttxt.setEditable(false);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        orderIDtxt = new javax.swing.JTextField();
        Nametxt = new javax.swing.JTextField();
        Addresstxt = new javax.swing.JTextField();
        DateTimetxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        Retrieve = new javax.swing.JButton();
        Paid = new javax.swing.JButton();
        Reset = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        Paymenttxt = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(700, 300));

        jLabel1.setText("Order ID");

        jLabel2.setText("Customer Name");

        jLabel3.setText("Address");

        jLabel4.setText("Date & Time");

        orderIDtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderIDtxtActionPerformed(evt);
            }
        });

        Addresstxt.setAutoscrolls(false);
        Addresstxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddresstxtActionPerformed(evt);
            }
        });

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setForeground(new java.awt.Color(255, 0, 0));
        jLabel5.setText("Every order only can pay with cash on delivery method.");

        Retrieve.setText("Get Info");
        Retrieve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RetrieveActionPerformed(evt);
            }
        });

        Paid.setText("Paid");
        Paid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaidActionPerformed(evt);
            }
        });

        Reset.setText("Reset");
        Reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetActionPerformed(evt);
            }
        });

        jLabel6.setText("Payment Status");

        Paymenttxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PaymenttxtActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("Record Pickup Details");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 459, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Paymenttxt, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(DateTimetxt, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(Addresstxt, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(Nametxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                                    .addComponent(orderIDtxt, javax.swing.GroupLayout.Alignment.TRAILING)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(Retrieve)
                                .addGap(93, 93, 93)
                                .addComponent(Paid)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Reset)
                                .addGap(12, 12, 12)))
                        .addGap(78, 78, 78))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addGap(19, 19, 19)
                .addComponent(jLabel5)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(orderIDtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Nametxt, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(Addresstxt, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(DateTimetxt, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Paymenttxt, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Retrieve)
                    .addComponent(Paid)
                    .addComponent(Reset))
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void orderIDtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderIDtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_orderIDtxtActionPerformed

    private void PaymenttxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaymenttxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PaymenttxtActionPerformed

    private void RetrieveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RetrieveActionPerformed
            orderIDtxt.setEditable(false);
            Nametxt.setEditable(false);
            Addresstxt.setEditable(false);
            DateTimetxt.setEditable(false);
            Paymenttxt.setEditable(false);
            
            ResultSet rs = selectRecord(orderIDtxt.getText());

            try {
                if (rs.next()) {
                    Nametxt.setText(rs.getString("CUSTNAME"));
                    Addresstxt.setText(rs.getString("ADDRESS"));
                    DateTimetxt.setText(rs.getString("DATE")+","+rs.getString("TIME"));
                    Paymenttxt.setText(rs.getString("STATUS"));
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Order ID Entered Not Found");
                    orderIDtxt.setEditable(true);
                    
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
    }//GEN-LAST:event_RetrieveActionPerformed

    private void PaidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PaidActionPerformed
            
            String orderID = orderIDtxt.getText();
            String Paid = "PAID";
            String Unpaid = "UNPAID";
            String payment = Paymenttxt.getText();
            StringBuilder sb = new StringBuilder();
    if (!orderIDtxt.getText().isEmpty() && !Paymenttxt.getText().isEmpty() && !Addresstxt.getText().isEmpty() && !DateTimetxt.getText().isEmpty() 
            && !Nametxt.getText().isEmpty()) { 
        if(payment.compareToIgnoreCase(Unpaid)== 0){
            try {
                
                pStmt_Update.setString(1, Paid);
                pStmt_Update.setString(2, orderID);


                pStmt_Update.executeUpdate();
                
                sb.append("ORDER ID      : " + orderIDtxt.getText() + "\n");
                sb.append("CUSTOMER NAME : " + Nametxt.getText() + "\n");
                sb.append("DATE & TIME   : " + DateTimetxt.getText() + "\n");
                sb.append("ADDRESS       : " + Addresstxt.getText() + "\n");
                sb.append("\n\nCurrent Payment Status Cash On Delivery is UNPAID.");



                sb.append("\n\nDo You Confirm Change The Payment Status Of This Order To PAID? ");

                int isConfirm = JOptionPane.showConfirmDialog(
                        null,
                        sb.toString(),
                        "Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (isConfirm == JOptionPane.YES_OPTION) {

                    JOptionPane.showMessageDialog(null, "PAYMENT STATUS FOR " + orderID + " HAD BEEN CHANGE TO PAID!");
                }
                
               
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            }
        }else if(payment.compareToIgnoreCase(Paid)== 0){
            JOptionPane.showMessageDialog(null, "The Payment Status for "+orderID + " already PAID.","Error", JOptionPane.ERROR_MESSAGE);
        }
        }else {
                    JOptionPane.showMessageDialog(null, "Please Fill Up All The Details", "Error", JOptionPane.ERROR_MESSAGE);
                }
        
    }//GEN-LAST:event_PaidActionPerformed

    private void AddresstxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddresstxtActionPerformed
        
    }//GEN-LAST:event_AddresstxtActionPerformed

    private void ResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetActionPerformed
                orderIDtxt.setText("");
                orderIDtxt.setEditable(true);
                Nametxt.setText("");
                DateTimetxt.setText("");
                Addresstxt.setText("");
                Paymenttxt.setText("");

                
                
                orderIDtxt.requestFocus();
    }//GEN-LAST:event_ResetActionPerformed

     private ResultSet selectRecord(String ORDERID) {
            ResultSet rs = null;

            try {
                pStmt_Select.setString(1, ORDERID);

                rs = pStmt_Select.executeQuery();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            }

            return rs;
        }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PaymentMethod.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PaymentMethod.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PaymentMethod.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PaymentMethod.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PaymentMethod().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Addresstxt;
    private javax.swing.JTextField DateTimetxt;
    private javax.swing.JTextField Nametxt;
    private javax.swing.JButton Paid;
    private javax.swing.JTextField Paymenttxt;
    private javax.swing.JButton Reset;
    private javax.swing.JButton Retrieve;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField orderIDtxt;
    // End of variables declaration//GEN-END:variables
}
