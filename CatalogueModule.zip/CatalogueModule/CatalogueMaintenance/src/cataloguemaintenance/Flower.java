package cataloguemaintenance;



/**
 *
 * @author jiash
 */
public class Flower {
    private String FID;
    private String FName;
   
    private int FPrice;
    private String FType;
    private String FOrigin;
    private int Funit;
            
    public Flower(){}
    
    public Flower(String FLOWERID,String FLOWERNAME,int FLOWERPRICE,String FLOWERTYPE,String FLOWERORIGIN,int FLOWERUNIT)
    {
        this.FID = FLOWERID;
        this.FName = FLOWERNAME;
        this.FPrice = FLOWERPRICE;
        this.FType = FLOWERTYPE;
        this.FOrigin = FLOWERORIGIN;
        this.Funit = FLOWERUNIT;
        
        
    }
    
    public void setfID(String FLOWERID){
        this.FID = FLOWERID;
        
    }
    
    public String getFID(){
        return FID;
    }
    
      public void setFName(String FLOWERNAME){
        this.FName = FLOWERNAME;
        
    }
    
    public String getFname(){
        return FName;
    }
    
    public void setFType(String FLOWERTYPE){
        this.FType=FLOWERTYPE;
    }
    
    public String getFType(){
        return FType;
    }
    
     public void FPrice(int FLOWERPRICE){
        this.FPrice = FLOWERPRICE;
        
    }

    public int getFPrice(){
        return FPrice;
    }
    
    public void setFOrigin(String FLOWERORIGIN){
        this.FOrigin = FLOWERORIGIN;
        
    }
    
    public String getFOrigin(){
        return FOrigin;
    }
    
    public void setFUnit(int FLOWERUNIT){
        this.Funit = FLOWERUNIT;
        
    }
    
    public int getFUnit(){
        return Funit;
    }
    

    
}
