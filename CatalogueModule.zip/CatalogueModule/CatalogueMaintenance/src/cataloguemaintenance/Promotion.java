/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cataloguemaintenance;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author jiash
 */
public class Promotion extends JFrame {
    
    private final String SQL_SELECT = "SELECT * FROM FLOWER WHERE FLOWERNAME = ?";
    private final String SQL_INSERT = "INSERT INTO PROMOTION VALUES (?,?,?,?,?)";
    
    private Connection con;
    private PreparedStatement pStmt_Select;
    private PreparedStatement pStmt_Insert;
    

    private JTextField txtPName = new JTextField();
    private JTextField txtFName = new JTextField();
    private JTextField txtFPrice = new JTextField();
    private JTextField txtDiscRate = new JTextField();
    private JTextField txtNPrice = new JTextField();
    
   
     public Promotion() {

        setLayout(new BorderLayout());
        add(getHeaderPanel(), BorderLayout.NORTH);
        add(getInputPanel(), BorderLayout.CENTER);
        add(getButtonPanel(), BorderLayout.SOUTH);
        
        try {
            initDbConnection();
            initPrepareStatement();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }

    }
    private JPanel getHeaderPanel() {
        JPanel panel = new JPanel(new FlowLayout());

        panel.add(new JLabel("Please Enter Flower Name And Click Retrieve Button. Then Click Generate Monthly Promotion."));
        
        return panel;

    }

    private JPanel getInputPanel() {

        JPanel panel = new JPanel(new GridLayout(5, 3));

        panel.add(new JLabel("Flower Name"));
        panel.add(txtFName);
        
        panel.add(new JLabel("Promotion Name:"));
        panel.add(txtPName);
     
        panel.add(new JLabel("Flower Price :"));
        panel.add(txtFPrice);
        txtFPrice.setEditable(false);
        
        panel.add(new JLabel("Discount Rate :"));
        panel.add(txtDiscRate);
        
        panel.add(new JLabel("Net  Price :"));
        panel.add(txtNPrice);
        txtNPrice.setEditable(false);

        return panel;
    }
    
     private JPanel getButtonPanel() {
         
        JPanel panel = new JPanel(new FlowLayout());
        JButton btnRetrieve = new JButton("Retrieve Flower Details");
        btnRetrieve.addActionListener(new RetrieveListener());
        
        JButton btnCalculate = new JButton("Calculate NetPrice");
        btnCalculate.addActionListener(new CalculateListener());
        
        JButton btnConfirm = new JButton("Generate Monthly Promotion");
        panel.add(btnConfirm);
        
         btnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                
            String PromotionName = txtPName.getText();
            String FlowerName = txtFName.getText();
            String FlowerPrice  = txtFPrice.getText();
            String DiscountRate = txtDiscRate.getText();
            String NetPrice = txtNPrice.getText();
            
        
            
            StringBuilder sb = new StringBuilder();

            try {
                
                double price = Double.parseDouble(FlowerPrice);
                double discountrate = Double.parseDouble(DiscountRate);
                double netprice= Double.parseDouble(NetPrice);
                
                pStmt_Insert.setString(1, PromotionName); 
                pStmt_Insert.setString(2, FlowerName);
                pStmt_Insert.setDouble(3, price);
                pStmt_Insert.setDouble(4, discountrate);
                pStmt_Insert.setDouble(5, netprice);
                

                pStmt_Insert.executeUpdate();

                sb.append("Flower Name : " + txtFName.getText() + "\n");
                sb.append("Promotion Name : " + txtPName.getText() + "\n");
                sb.append("Flower Price: " + txtFPrice.getText() + "\n");
                sb.append("Discount Rate  : " + txtDiscRate.getText() + "\n");
                sb.append("Net Price  : " + txtNPrice.getText() + "\n");
                

                sb.append("\n\nConfirm Changes? ");

                int isConfirm = JOptionPane.showConfirmDialog(
                        null,
                        sb.toString(),
                        "Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (isConfirm == JOptionPane.YES_OPTION) {

                    JOptionPane.showMessageDialog(null, "Promotion had been created!!");

                }

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            }
                
    
                
            }

        });
        
    
        
        
            JButton btnReset = new JButton("Reset");
        
        btnReset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtPName.setText("");
                txtFName.setText(""); 
                txtFPrice.setText(""); 
                txtDiscRate.setText(""); 
                txtNPrice.setText(""); 
                
                txtFPrice.setEditable(false);
                txtNPrice.setEditable(false);
                
                txtFName.requestFocus();
                
            }

        });
        panel.add(btnRetrieve);
        panel.add(btnConfirm);
        panel.add(btnCalculate);
        panel.add(btnReset);

        return panel;

    }
     
    
       
     
     
     private class RetrieveListener implements ActionListener {
         
          @Override
        public void actionPerformed(ActionEvent e) {
        
        
         ResultSet rs = selectRecord(txtFName.getText());
            
            try {
                if (rs.next()) {
                    
                  
                    txtFName.setText(rs.getString("FLOWERNAME"));
                    txtFPrice.setText(rs.getString("FLOWERPRICE"));
                   
                   
                    
                    
                   txtFPrice.setEditable(false);
                   txtNPrice.setEditable(false);
                
                    
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Flower Name Entered Not Found");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        }
        
        
        private ResultSet selectRecord(String FName) {
            ResultSet rs = null;

            try {
                pStmt_Select.setString(1, FName);

                rs = pStmt_Select.executeQuery();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            }

            return rs;
        }
     
     }
     
        private class CalculateListener implements ActionListener {
         
          @Override
        public void actionPerformed(ActionEvent e) {
            
            double P = Double.parseDouble(txtFPrice.getText());
            double D = Double.parseDouble(txtDiscRate.getText());
            
            double Discount = P*D;
            double Net_amount = P - Discount;
            String netamount = new Double(Net_amount).toString();
            
            txtNPrice.setText(netamount);
        
        
        
        }
       }
    
   private void initDbConnection() throws SQLException {
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/FlowerDB", "nbuser", "nbuser");
    }

    private void initPrepareStatement() throws SQLException {
        pStmt_Select = con.prepareStatement(SQL_SELECT);
        pStmt_Insert = con.prepareStatement(SQL_INSERT); 
               
        
    }
        public static void main(String[] args) {
        Promotion objFrame = new Promotion();

        objFrame.setTitle("Generate Monthly Promotion");
        objFrame.setSize(700, 300);
        objFrame.setLocationRelativeTo(null);
        objFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        objFrame.setVisible(true);
    }
    
}
