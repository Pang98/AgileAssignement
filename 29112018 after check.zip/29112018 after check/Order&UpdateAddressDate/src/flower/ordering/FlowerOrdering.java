package flower.ordering;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;


public class FlowerOrdering extends JFrame{
    
    private final String SQL_INSERT = "INSERT INTO FLOWERORDER (ORDERID , CUSTIC, FLOWERTYPE ,QUANTITIES )VALUES (?,?,?,?)";
    private final String SQL_SELECT = "SELECT * FROM CUSTOMER WHERE CUSTIC = ? ";
    private final String SQL_SELECT1 = "SELECT * FROM FLOWERORDER WHERE ORDERID = ? ";
    
    private JLabel OrderID = new JLabel("     Order ID :");
    private JLabel NameIC = new JLabel("     Customer IC(NAME) :");
    private JLabel FlowerType = new JLabel("     Flower Type :");
    private JLabel Quantities = new JLabel("     Flower Quantities :");
    
    
    private JTextField txtOrderID = new JTextField();
    private JTextField txtNameIC = new JTextField();
    private JButton btnRetrieve = new JButton("Retrieve");
    private JButton btnConfirm = new JButton("Confirm");
    private JButton btnReset = new JButton("Reset");
    
    String[] FlowerString = { "Rose", "Sun Flower", "Lily", "Anemone", "Dahlia" };
    JComboBox FlowerList = new JComboBox(FlowerString);
    
    SpinnerModel value =  
             new SpinnerNumberModel(0, //initial value  
                0, //minimum value  
                100, //maximum value  
                1); //step  
    JSpinner spinner = new JSpinner(value);   
    
    private String icnum = "";

    private Connection con;
    private PreparedStatement pStmt_Insert,pStmt_Select,pStmt_Select1 ;
    ResultSet rs;
    
    int generatedKey = 0;
    public FlowerOrdering() {

        setLayout(new BorderLayout());
        
        try {
            initDbConnection();
            initPrepareStatement();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }

        add(getHeaderPanel(), BorderLayout.NORTH);
        add(getInputPanel(), BorderLayout.CENTER);
        add(getButtonPanel(), BorderLayout.SOUTH);

     
    }
    
    private JPanel getInputPanel() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        
        
        panel.add(OrderID);
        panel.add(txtOrderID);
        
        panel.add(NameIC);
        panel.add(txtNameIC);
        
        
        FlowerList.setSelectedIndex(4);
        panel.add(FlowerType);
        panel.add(FlowerList);     

        panel.add(Quantities);
        panel.add(spinner);

       

        return panel;
    }
    
    
    
    private JPanel getHeaderPanel() {

        JPanel panel = new JPanel(new GridLayout(4, 1));

        panel.add(new JLabel("  -----Please select flower type and the quantites you needed----- "));
       

        return panel;
    }
    
    private JPanel getButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout());
        
        btnRetrieve.addActionListener(new RetrieveListener());
        btnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder sb = new StringBuilder();              
                if (!txtOrderID.getText().isEmpty() && !txtNameIC.getText().isEmpty()) {                   

                        sb.append("Order ID : " + txtOrderID.getText() + "\n");
                        sb.append("Customer Name : " + txtNameIC.getText() + "\n"); 
                        sb.append("Flower Type : " + FlowerList.getSelectedItem()+ "\n");  
                        sb.append("Quantities : " + spinner.getValue() + "\n");
                                         
                        sb.append("\n\nClick Confirm To Continue:");

                        int isConfirm = JOptionPane.showConfirmDialog(
                                null,
                                sb.toString(),
                                "Confirmation",
                                JOptionPane.YES_NO_OPTION);

                        if (isConfirm == JOptionPane.YES_OPTION) {
                            
                            String OrderID = txtOrderID.getText();
                            String Quantities = String.valueOf(spinner.getValue());
                            String FlowerName = (String)FlowerList.getSelectedItem();
                            

                            try {
                                pStmt_Insert.setString(1, OrderID);
                                pStmt_Insert.setString(2, icnum);
                                pStmt_Insert.setString(3, FlowerName);
                                pStmt_Insert.setString(4, Quantities);
                                                            
                                pStmt_Insert.executeUpdate();
                                
                                JOptionPane.showMessageDialog(null, "New Order Record Had Been Created!");
                            } catch (SQLException ex) {
                                JOptionPane.showMessageDialog(null, ex.getMessage());
                            }

                        }
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Please Fill Up All The Details", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }

        });
        
        

        btnReset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                txtOrderID.setText("");
                txtNameIC.setText("");
                FlowerList.setSelectedIndex(1);
                spinner.setValue(1);
            }
        });


        panel.add(btnRetrieve); 
        panel.add(btnConfirm);     
        panel.add(btnReset);
        return panel;
    }
    
    private class RetrieveListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            txtNameIC.setEditable(false);
            icnum = txtNameIC.getText();
            ResultSet rs = selectRecord(txtNameIC.getText());

            
            try {
                if (rs.next()) {
                    txtNameIC.setText(rs.getString("CUSTNAME"));


                } else {
                    JOptionPane.showMessageDialog(null, "Order ID Entered Not Found");
                    txtNameIC.setEditable(true);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        }
    
        private ResultSet selectRecord(String CustIC) {
            ResultSet rs = null;

            try {              
                pStmt_Select.setString(1, CustIC);

                rs = pStmt_Select.executeQuery();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            }

            return rs;
        }
    }
    
    
    
    
        private void initDbConnection() throws SQLException {
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/FlowerShopDB", "nbuser", "nbuser");
    }

    private void initPrepareStatement() throws SQLException {
        pStmt_Insert = con.prepareStatement(SQL_INSERT,Statement.RETURN_GENERATED_KEYS); 
        pStmt_Select = con.prepareStatement(SQL_SELECT);
        pStmt_Select1 = con.prepareStatement(SQL_SELECT1);
        
    }
    
    public static void main(String[] args) {
        FlowerOrdering objFrame = new FlowerOrdering();

        objFrame.setTitle("New Order Records");
        objFrame.setSize(600, 300);
        objFrame.setLocationRelativeTo(null);
        objFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        objFrame.setVisible(true);
    }
    
    
}
