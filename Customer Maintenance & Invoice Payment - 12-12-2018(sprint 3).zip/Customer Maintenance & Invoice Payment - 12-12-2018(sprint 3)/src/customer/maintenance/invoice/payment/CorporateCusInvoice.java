
package customer.maintenance.invoice.payment;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CorporateCusInvoice extends JFrame {

    private String DEFAULT_QUERY = "SELECT O.ORDERDATE AS ORDER_DATE, O.FLOWERTYPE AS FLOWER, F.UNITPRICE AS UNIT_PRICE, O.QUANTITIES AS QUANTITIES_ORDERED, F.UNITPRICE*O.QUANTITIES AS SUBTOTAL  "
            + "FROM FLOWERORDER O, COMPANY C, FLOWER F "
            + "WHERE C.REGNO = O.CUSTIC AND O.CUSTIC = '!' AND F.FLOWERNAME = O.FLOWERTYPE AND (O.ORDERDATE BETWEEN '2018-?-01' AND '2018-?-31') ORDER BY O.ORDERDATE";
    
    private String QUERY = "SELECT O.ORDERDATE AS ORDER_DATE, O.FLOWERTYPE AS FLOWER, F.UNITPRICE AS UNIT_PRICE, O.QUANTITIES AS QUANTITIES_ORDERED, F.UNITPRICE*O.QUANTITIES AS SUBTOTAL  "
            + "FROM FLOWERORDER O, COMPANY C, FLOWER F "
            + "WHERE C.REGNO = O.CUSTIC AND O.CUSTIC = '!' AND F.FLOWERNAME = O.FLOWERTYPE AND (O.ORDERDATE BETWEEN '2018-?-01' AND '2018-?-31') ORDER BY O.ORDERDATE";
    
    private final String SQL_SELECT = "SELECT * FROM COMPANY WHERE REGNO = ?";
   
    private JTextField txtRegNo = new JTextField();
    private JTextField txtComName = new JTextField();      
    private JTextField txtMonth = new JTextField();
    String[] comboMonth = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
    JComboBox monthList = new JComboBox(comboMonth);
    
    
    private static String title = "Month Invoice", regNo = null, name = null, address = null, contact = null, email = null, month = null;
    
    private Connection con;
    private PreparedStatement pStmt_Select;
    

    public CorporateCusInvoice() {

        setLayout(new BorderLayout());
        add(getHeaderPanel(), BorderLayout.NORTH);
        add(getInputPanel(), BorderLayout.CENTER);
        add(getButtonPanel(), BorderLayout.SOUTH);
        
        try {
            initDbConnection();
            initPrepareStatement();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }

    }
    private JPanel getHeaderPanel() {
        JPanel panel = new JPanel(new FlowLayout());

        panel.add(new JLabel("Please Enter Company Registration Number And Click Retrieve Button. Then Click Generate Monthly Invoice."));
        
        return panel;

    }

    private JPanel getInputPanel() {

        JPanel panel = new JPanel(new GridLayout(4, 2));

        panel.add(new JLabel("Registration No:"));
        panel.add(txtRegNo);
        
        panel.add(new JLabel("Company Name"));
        panel.add(txtComName);
        txtComName.setEditable(false);
        
        panel.add(new JLabel("Invoice For Month:"));
        panel.add(monthList);
        

        return panel;
    }

    private JPanel getButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout());
        JButton btnRetrieve = new JButton("Retrieve Company Details");
        btnRetrieve.addActionListener(new RetrieveListener());
        
        JButton btnConfirm = new JButton("Generate Monthly Invoice");
        panel.add(btnConfirm);

        btnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                int month_index = monthList.getSelectedIndex() + 1;
                month = month_index + "";
                String month_word = monthList.getSelectedItem() + "";
                DEFAULT_QUERY = DEFAULT_QUERY.replace("!", txtRegNo.getText());
                DEFAULT_QUERY = DEFAULT_QUERY.replace("?", month);
                regNo = txtRegNo.getText();
                DisplayQueryResults displayQueryResultsnew = new DisplayQueryResults(DEFAULT_QUERY, title, month_word, regNo, name, address, contact, email);
                displayQueryResultsnew.setTitle("Corporate Monthly Invoice");
                displayQueryResultsnew.setSize(900, 300);
                displayQueryResultsnew.setLocationRelativeTo(null);
                displayQueryResultsnew.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                displayQueryResultsnew.setVisible(true);
                DEFAULT_QUERY = QUERY;
                
            }

        });
        
        JButton btnReset = new JButton("Reset");
        
        btnReset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtRegNo.setText("");
                txtComName.setText("");                             
                txtRegNo.setEditable(true);
                txtComName.setEditable(true);                              
                txtRegNo.requestFocus();
                txtMonth.setText("");
            }

        });
        panel.add(btnRetrieve);
        panel.add(btnConfirm);
        panel.add(btnReset);

        return panel;

    }
    
    private class RetrieveListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            
            ResultSet rs = selectRecord(txtRegNo.getText());
            
            try {
                if (rs.next()) {
                    
                    txtComName.setText(rs.getString("COMPANYNAME"));
                    name = txtComName.getText();
                    email = rs.getString("COMPANYEMAIL");                  
                    address = rs.getString("COMPANYADD");
                    contact = rs.getString("COMPANYCONTACT");
                                       
                    txtComName.setEditable(false); 
                    txtRegNo.setEditable(false);
                    
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Registation Number Entered Not Found");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        }

        private ResultSet selectRecord(String regNo) {
            ResultSet rs = null;

            try {
                pStmt_Select.setString(1, regNo);

                rs = pStmt_Select.executeQuery();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            }

            return rs;
        }
    }
    
    private void initDbConnection() throws SQLException {
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/FlowerShopDB", "nbuser", "nbuser");
    }

    private void initPrepareStatement() throws SQLException {
        pStmt_Select = con.prepareStatement(SQL_SELECT);
               
        
    }
   

    public static void main(String[] args) {
        CorporateCusInvoice objFrame = new CorporateCusInvoice();

        objFrame.setTitle("Corporate Monthly Invoice");
        objFrame.setSize(700, 300);
        objFrame.setLocationRelativeTo(null);
        objFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        objFrame.setVisible(true);
    }
}
