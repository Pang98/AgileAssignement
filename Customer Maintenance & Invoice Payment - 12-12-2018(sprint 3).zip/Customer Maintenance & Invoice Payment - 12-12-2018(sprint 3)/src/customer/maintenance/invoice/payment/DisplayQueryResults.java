package customer.maintenance.invoice.payment;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.swing.SwingConstants;

public class DisplayQueryResults extends JFrame {

    private static final String HOST = "jdbc:derby://localhost:1527/FlowerShopDB";
    private static final String USER = "nbuser";
    private static final String PASSWORD = "nbuser";
    private static String DEFAULT_QUERY = null;
    private static String Title = null, regNo, name, address, contact, email, month_word;
    

    private ResultSetTableModel rsModel;
    private JTable tblResult;
    private TableRowSorter<TableModel> sorter;

    public DisplayQueryResults() {

    }

    public DisplayQueryResults(String QUERY, String title, String month_word, String regNo, String name, String address, String contact, String email) {
        try {
                     
            DEFAULT_QUERY = QUERY;
            rsModel = new ResultSetTableModel(HOST, USER, PASSWORD, QUERY);
            tblResult = new JTable(rsModel);

            tblResult.setRowSorter(sorter); 
            
            Title = title + " - " + month_word;
            this.regNo = regNo;
            this.name = name;
            this.address = address;
            this.contact = contact;
            this.email = email;
            
            add(getHeaderPanel(), BorderLayout.NORTH);

            add(new JScrollPane(tblResult), BorderLayout.CENTER);

            addWindowListener(new WindowCloseListener()); // ensure db connection was closed when user quits application
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            rsModel.disconnectDb();
            System.exit(1); // exit with error
        }
    }

    private JPanel getHeaderPanel() {
        JPanel panel = new JPanel(new GridLayout(6,3));
        
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        System.out.println(dateFormat.format(date));
        
        panel.add(new JLabel(""));
        panel.add(getCenterLabel(name + "(" + regNo + ")"));
        panel.add(new JLabel(""));
        
        panel.add(getLeftAlignedLabel("Address: " + address));
        panel.add(new JLabel(""));
        panel.add(new JLabel(""));
        
        panel.add(getLeftAlignedLabel("Email: " + email));
        panel.add(new JLabel(""));
        panel.add(new JLabel(""));
        
        panel.add(getLeftAlignedLabel("Contact: " + contact));
        panel.add(new JLabel(""));
        panel.add(new JLabel(""));
        
        panel.add(new JLabel(""));
        panel.add(new JLabel(""));
        panel.add(getRightAlignedLabel("Generated on : " + dateFormat.format(date)));
        
        panel.add(new JLabel(""));
        panel.add(getCenterLabel(Title));
        panel.add(new JLabel(""));

        return panel;
    }
    public JLabel getLeftAlignedLabel(String text) {
        return new JLabel(text, SwingConstants.LEFT);
    }
    
    public JLabel getCenterLabel(String text) {
        return new JLabel(text, SwingConstants.CENTER);
    }

    public JLabel getRightAlignedLabel(String text) {
        return new JLabel(text, SwingConstants.RIGHT);
    }

    private class WindowCloseListener extends WindowAdapter {

        @Override
        public void windowClosed(WindowEvent event) {
            rsModel.disconnectDb();
            
        }
    }

    public static void main(String[] args) {
        DisplayQueryResults objFrame = new DisplayQueryResults();

        objFrame.setTitle("Monthly Invoice");
        objFrame.setSize(700, 300);
        objFrame.setLocationRelativeTo(null);
        objFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        objFrame.setVisible(true);
    }
}
