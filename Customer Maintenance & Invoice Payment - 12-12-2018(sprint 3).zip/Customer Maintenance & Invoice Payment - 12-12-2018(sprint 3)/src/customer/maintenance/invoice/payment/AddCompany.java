package customer.maintenance.invoice.payment;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class AddCompany extends JFrame {

    private final String SQL_INSERT = "INSERT INTO COMPANY VALUES (?,?,?,?,?)";
    

    private JLabel comRegNo = new JLabel("     Company Registration No (111111-A)");
    private JLabel comName = new JLabel("     Company Name");   
    private JLabel comEmail = new JLabel("     Company Email");
    private JLabel comAddress = new JLabel("     Company Address");
    private JLabel comContact = new JLabel("     Company Contact Number (Without '-')");
    
    
    private JTextField txtComRegNo = new JTextField();
    private JTextField txtComName = new JTextField();
    private JTextField txtComEmail = new JTextField();
    private JTextField txtComAddress = new JTextField();
    private JTextField txtComContact = new JTextField();
    
    
    private JButton btnConfirm = new JButton("Confirm"); 
    private JButton btnReset = new JButton("Reset");
    
    private Connection con;
    private PreparedStatement pStmt_Insert;
    
    
    ResultSet rs;

    public AddCompany() {

        setLayout(new BorderLayout());
        
        try {
            initDbConnection();
            initPrepareStatement();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }

        add(getHeaderPanel(), BorderLayout.NORTH);
        add(getInputPanel(), BorderLayout.CENTER);
        add(getButtonPanel(), BorderLayout.SOUTH);

     
    }
    

    private JPanel getHeaderPanel() {

        JPanel panel = new JPanel(new GridLayout(4, 1));

        panel.add(new JLabel("  Please Follow Instrcutions Below: "));
        panel.add(new JLabel("  1. Enter Company Details"));
        panel.add(new JLabel("  2. Click Confirm Button To Add"));
       

        return panel;
    }

    private JPanel getInputPanel() {
        JPanel panel = new JPanel(new GridLayout(7, 2));
         
        panel.add(comRegNo);
        panel.add(txtComRegNo);     

        panel.add(comName);
        panel.add(txtComName);
  
        panel.add(comEmail);
        panel.add(txtComEmail);     

        panel.add(comAddress);
        panel.add(txtComAddress);
        
        panel.add(comContact);
        panel.add(txtComContact); 
        
       

        return panel;
    }

    private JPanel getButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout());

        btnConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder sb = new StringBuilder();              
                
                if (!txtComRegNo.getText().isEmpty() && !txtComName.getText().isEmpty() && !txtComEmail.getText().isEmpty() && !txtComAddress.getText().isEmpty()
                        && !txtComContact.getText().isEmpty()) {                   

                        sb.append("Customer IC : " + txtComRegNo.getText() + "\n");
                        sb.append("Customer Name : " + txtComName.getText() + "\n");              
                        sb.append("Customer Email: " + txtComEmail.getText() + "\n");
                        sb.append("Customer Address : " + txtComAddress.getText() + "\n");
                        sb.append("Customer Contact Number : " + txtComContact.getText() + "\n");
                        
                        
                        sb.append("\n\nClick Confirm To Continue:");

                        int isConfirm = JOptionPane.showConfirmDialog(
                                null,
                                sb.toString(),
                                "Confirmation",
                                JOptionPane.YES_NO_OPTION);

                        if (isConfirm == JOptionPane.YES_OPTION) {

                            String comRegNo = txtComRegNo.getText();
                            String comName = txtComName.getText();
                            String comEmail = txtComEmail.getText();
                            String comAddress = txtComAddress.getText();
                            String comContact = txtComContact.getText();
                            
                            

                            try {

                                pStmt_Insert.setString(1, comRegNo);
                                pStmt_Insert.setString(2, comName);                                
                                pStmt_Insert.setString(3, comAddress);
                                pStmt_Insert.setString(4, comContact);
                                pStmt_Insert.setString(5, comEmail);
                                
                                
                                
                                pStmt_Insert.executeUpdate();
                                
                                JOptionPane.showMessageDialog(null, "New Company Record Had Been Added To The Database!");

                            } catch (SQLException ex) {
                                JOptionPane.showMessageDialog(null, ex.getMessage());
                            }

                        }
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Please Fill Up All The Details", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }

        });

        btnReset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                txtComRegNo.setText("");
                txtComName.setText("");
                txtComEmail.setText("");
                txtComAddress.setText("");
                txtComContact.setText("");
                
            }
        });


        panel.add(btnConfirm);     
        panel.add(btnReset);
        return panel;
    }
    
    
    private void initDbConnection() throws SQLException {
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/FlowerShopDB", "nbuser", "nbuser");
    }

    private void initPrepareStatement() throws SQLException {
        pStmt_Insert = con.prepareStatement(SQL_INSERT);       
        
    }

    public static void main(String[] args) {
        AddCompany objFrame = new AddCompany();

        objFrame.setTitle("Add Company Records");
        objFrame.setSize(600, 300);
        objFrame.setLocationRelativeTo(null);
        objFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        objFrame.setVisible(true);
    }

}
