/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customer.maintenance.invoice.payment;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author ACER
 */
public class UpdateCompany extends JFrame{
    
    static UpdateCompany UpdateCustomer;
    
    private final String SQL_SELECT = "SELECT * FROM COMPANY WHERE REGNO = ?";
    private final String SQL_UPDATE = "UPDATE COMPANY " + "SET COMPANYEMAIL = ?," + " COMPANYADD = ?," + " COMPANYCONTACT = ?," + "WHERE REGNO = ?";

    private JLabel comRegNo = new JLabel("     Company Registration No (111111-A)");
    private JLabel comName = new JLabel("     Company Name");   
    private JLabel comEmail = new JLabel("     Company Email");
    private JLabel comAddress = new JLabel("     Company Address");
    private JLabel comContact = new JLabel("     Company Contact Number (Without '-')");
    

    private JTextField txtComRegNo = new JTextField();
    private JTextField txtComName = new JTextField();
    private JTextField txtComEmail = new JTextField();
    private JTextField txtComAddress = new JTextField();
    private JTextField txtComContact = new JTextField();
    
    
    private JButton btnReset = new JButton("Reset");
    private JButton btnRetrieve = new JButton("Retrieve");
    private JButton btnUpdate = new JButton("Update");
    
    private Connection con;
    private PreparedStatement pStmt_Select, pStmt_Update;
    
    public UpdateCompany(){
    setLayout(new BorderLayout());

        add(getHeaderPanel(), BorderLayout.NORTH);
        add(getDisplayPanel(), BorderLayout.CENTER);
        add(getButtonPanel(), BorderLayout.SOUTH);

        try {
            initDbConnection();
            initPrepareStatement();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }

    }

    private JPanel getHeaderPanel() {

        JPanel panel = new JPanel(new FlowLayout());

        panel.add(new JLabel("Please Enter Company Registration Number And Click Retrieve Button To Edit Details"));
       

        return panel;
    }

    private JPanel getDisplayPanel() {
        JPanel panel = new JPanel(new GridLayout(6, 2));

        panel.add(comRegNo);     
        panel.add(txtComRegNo);
        
        panel.add(comName);     
        panel.add(txtComName);
        txtComName.setEditable(false);
     
        panel.add(comEmail);        
        panel.add(txtComEmail);   
        txtComEmail.setEditable(false);
               
        panel.add(comAddress);    
        panel.add(txtComAddress);
        txtComAddress.setEditable(false);
        
        panel.add(comContact);      
        panel.add(txtComContact);
        txtComContact.setEditable(false);
        
        
        
        return panel;
    }

    private JPanel getButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout());
        
        btnRetrieve.addActionListener(new RetrieveListener());
        btnUpdate.addActionListener(new UpdateListener());
        btnReset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtComRegNo.setText("");
                txtComName.setText("");              
                txtComEmail.setText("");
                txtComAddress.setText("");
                txtComContact.setText("");
                
                
                txtComRegNo.setEditable(true);
                txtComName.setEditable(false);   
                txtComEmail.setEditable(false); 
                txtComAddress.setEditable(false); 
                txtComContact.setEditable(false); 
                
                 
                txtComRegNo.requestFocus();
            }

        });
       
        
        panel.add(btnUpdate);
        panel.add(btnRetrieve);
        panel.add(btnReset);
        
        return panel;

    }

    private class RetrieveListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            
            ResultSet rs = selectRecord(txtComRegNo.getText());
            

            try {
                if (rs.next()) {
                    txtComRegNo.setText(rs.getString("REGNO"));
                    txtComName.setText(rs.getString("COMPANYNAME"));
                    txtComEmail.setText(rs.getString("COMPANYEMAIL"));                  
                    txtComAddress.setText(rs.getString("COMPANYADD"));
                    txtComContact.setText(rs.getString("COMPANYCONTACT"));
                    
                    
                    
                    
                    txtComRegNo.setEditable(false);
                    txtComName.setEditable(false); 
                    txtComEmail.setEditable(true);
                    txtComAddress.setEditable(true);
                    txtComContact.setEditable(true);
                    
                    
                    
                } else {
                    JOptionPane.showMessageDialog(null, "Registation Number Entered Not Found");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage());
            }
        }

        private ResultSet selectRecord(String regNo) {
            ResultSet rs = null;

            try {
                pStmt_Select.setString(1, regNo);

                rs = pStmt_Select.executeQuery();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            }

            return rs;
        }
    }

    private class UpdateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String contactNum = txtComContact.getText();
            String email = txtComEmail.getText();
            String address = txtComAddress.getText();
            String regNo = txtComRegNo.getText();
            
            StringBuilder sb = new StringBuilder();

            try {
                pStmt_Update.setString(1, email);
                pStmt_Update.setString(2, address);
                pStmt_Update.setString(3, contactNum);              
                pStmt_Update.setString(4, regNo);

                pStmt_Update.executeUpdate();

                sb.append("Registration Number : " + txtComRegNo.getText() + "\n");
                sb.append("Name : " + txtComName.getText() + "\n");
                sb.append("Email : " + txtComEmail.getText() + "\n");
                sb.append("Address : " + txtComAddress.getText() + "\n");
                sb.append("Contact Number : " + txtComContact.getText() + "\n");
                
                

                sb.append("\n\nConfirm Changes? ");

                int isConfirm = JOptionPane.showConfirmDialog(
                        null,
                        sb.toString(),
                        "Confirmation",
                        JOptionPane.YES_NO_OPTION);

                if (isConfirm == JOptionPane.YES_OPTION) {

                    JOptionPane.showMessageDialog(null, "Changes For " + regNo + " Had Been Saved!");
                }

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    

    private void initDbConnection() throws SQLException {
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/FlowerShopDB", "nbuser", "nbuser");
    }

    private void initPrepareStatement() throws SQLException {
        pStmt_Select = con.prepareStatement(SQL_SELECT);
        pStmt_Update = con.prepareStatement(SQL_UPDATE);       
        
    }

    public static void main(String[] args) {
        UpdateCompany objFrame = new UpdateCompany();

        objFrame.setTitle("Update Company Data");
        objFrame.setSize(700, 400);
        objFrame.setLocationRelativeTo(null);
        objFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        objFrame.setVisible(true);
    }
}
