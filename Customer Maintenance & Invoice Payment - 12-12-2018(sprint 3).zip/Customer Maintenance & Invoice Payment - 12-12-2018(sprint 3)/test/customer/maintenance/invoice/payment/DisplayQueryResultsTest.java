/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customer.maintenance.invoice.payment;

import javax.swing.JLabel;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author PC CUSTOM
 */
public class DisplayQueryResultsTest {
    
    public DisplayQueryResultsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getLeftAlignedLabel method, of class DisplayQueryResults.
     */
    @Test
    public void testGetLeftAlignedLabel() {
        System.out.println("getLeftAlignedLabel");
        String text = "a";
        DisplayQueryResults instance = new DisplayQueryResults();
        JLabel expResult = null;
        JLabel result = instance.getLeftAlignedLabel(text);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getCenterLabel method, of class DisplayQueryResults.
     */
    @Test
    public void testGetCenterLabel() {
        System.out.println("getCenterLabel");
        String text = "a";
        DisplayQueryResults instance = new DisplayQueryResults();
        JLabel expResult = null;
        JLabel result = instance.getCenterLabel(text);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of getRightAlignedLabel method, of class DisplayQueryResults.
     */
    @Test
    public void testGetRightAlignedLabel() {
        System.out.println("getRightAlignedLabel");
        String text = "a";
        DisplayQueryResults instance = new DisplayQueryResults();
        JLabel expResult = instance.getRightAlignedLabel(text);
        JLabel result = instance.getRightAlignedLabel(text);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of main method, of class DisplayQueryResults.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        DisplayQueryResults.main(args);
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
